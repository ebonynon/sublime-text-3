## Expected Behaviour

## Actual Behaviour

## Steps to Reproduce

## ST3, Anaconda and OS versions

## ST3 Console Logs

## Anaconda's JsonServer Logs
**Note**: Anaconda's JsonServer logs can be found in:
* Linux: ~/.local/share/anaconda/logs
* OS X: ~/Library/Logs/anaconda
* Windows: %APPDATA\\Anaconda\\Logs
